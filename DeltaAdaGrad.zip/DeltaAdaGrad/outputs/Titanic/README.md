# Titanic

- Epochs: 10,000
- Learning Rate: 0.001
- Run Time
    - Device: NVIDIA GeForce RTX 3090
    - AdaGrad: 63 seconds
    - Adam: 64 seconds
    - DeltaAdaGrad: 75 seconds
