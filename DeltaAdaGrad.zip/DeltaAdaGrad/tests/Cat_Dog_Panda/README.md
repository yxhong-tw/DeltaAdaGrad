# Dataset
link: https://www.kaggle.com/datasets/ashishsaxena2209/animal-image-datasetdog-cat-and-panda
To run this code, please place the animals folder downloaded from the link above in the test/Cat_Dog_Panda folder.
